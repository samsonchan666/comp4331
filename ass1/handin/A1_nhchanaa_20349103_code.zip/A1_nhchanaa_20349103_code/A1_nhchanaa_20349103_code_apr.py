"""
Description     : Simple Python implementation of the Apriori Algorithm

Usage:
    $python apriori.py
"""

import sys
import time

from itertools import chain, combinations
from collections import defaultdict
from optparse import OptionParser


def subsets(arr):
    """ Returns non empty subsets of arr"""
    return chain(*[combinations(arr, i + 1) for i, a in enumerate(arr)])


def returnItemsWithMinSupport(itemSet, transactionList, minSupport, freqSet):
        """calculates the support for items in the itemSet and returns a subset
       of the itemSet each of whose elements satisfies the minimum support"""
        _itemSet = set()
        localSet = defaultdict(int)

        for item in itemSet:
                for transaction in transactionList:
                        if item.issubset(transaction):
                                #print item
                                freqSet[item] += 1
                                localSet[item] += 1

        for item, count in localSet.items():
                support = float(count)/len(transactionList)

                if support >= minSupport:
                        _itemSet.add(item)

        return _itemSet


def joinSet(itemSet, length):
        """Join a set with itself and returns the n-element itemsets"""
        return set([i.union(j) for i in itemSet for j in itemSet if len(i.union(j)) == length])


def getItemSetTransactionList(data_iterator):
    transactionList = list()
    itemSet = set()
    for record in data_iterator:
        transaction = frozenset(record)
        transactionList.append(transaction)
        for item in transaction:
            itemSet.add(frozenset([item]))              # Generate 1-itemSets
    return itemSet, transactionList


def runApriori(data_iter, minSupport, minConfidence):
    """
    run the apriori algorithm. data_iter is a record iterator
    Return both:
     - items (tuple, support)
     - rules ((pretuple, posttuple), confidence)
    """
    print("start apriori....")

    itemSet, transactionList = getItemSetTransactionList(data_iter)

    #print(len(itemSet))
    print(len(transactionList))
    #print(transactionList)

    freqSet = defaultdict(int)
    largeSet = dict()
    # Global dictionary which stores (key=n-itemSets,value=support)
    # which satisfy minSupport

    assocRules = dict()
    # Dictionary which stores Association Rules

    oneCSet = returnItemsWithMinSupport(itemSet,
                                        transactionList,
                                        minSupport,
                                        freqSet)

    currentLSet = oneCSet
    k = 2
    while(currentLSet != set([])):
        largeSet[k-1] = currentLSet
        currentLSet = joinSet(currentLSet, k)
        currentCSet = returnItemsWithMinSupport(currentLSet,
                                                transactionList,
                                                minSupport,
                                                freqSet)
        currentLSet = currentCSet
        k = k + 1

    def getSupport(item):
            """local function which Returns the support of an item"""
            return float(freqSet[item])/len(transactionList)

    toRetItems = []
    for key, value in largeSet.items():
        toRetItems.extend([(tuple(item), getSupport(item))
                           for item in value])

    toRetRules = []
    """
    for key, value in list(largeSet.items())[1:]:
        for item in value:
            _subsets = map(frozenset, [x for x in subsets(item)])
            for element in _subsets:
                remain = item.difference(element)
                if len(remain) > 0:
                    confidence = getSupport(item)/getSupport(element)
                    if confidence >= minConfidence:
                        toRetRules.append(((tuple(element), tuple(remain)),
                                           confidence))
                                           """
    print("Apriori finished....")

    return toRetItems, toRetRules


def printResults(items, rules):
    """prints the generated itemsets sorted by support and the confidence rules sorted by confidence"""
    
    ''' Write frequent item set to a file'''
    file = open('frequentItemSet.txt', 'w')

    print(len(items))
    for item, support in sorted(items, key=lambda item_support: item_support[1]):
        #print("reach here")
        #print("item: %s , %.3f" % (str(item), support))
        file.write("%s\n" % str(item))
    file.close()

    """
    print("\n------------------------ RULES:")
    for rule, confidence in sorted(rules, key=lambda rule_confidence: rule_confidence[1]):
        pre, post = rule
        print("Rule: %s ==> %s , %.3f" % (str(pre), str(post), confidence))
    """
        


def dataFromFile(fname):
        """Function which reads from the file and yields a generator"""
        file_iter = open(fname, 'rU')
        for line in file_iter:
                #line = line.strip().rstrip(',')                         # Remove trailing comma
                #line = line.strip()                         # Remove trailing comma
                #record = frozenset(line.split(','))
                record = frozenset(line.split())
                yield record


if __name__ == "__main__":

    start_time = time.time()

    inFile = None

    inFile = dataFromFile("freq_items_dataset.txt")
    #inFile = dataFromFile("tmp.txt")
    #inFile = dataFromFile("INTEGRATED-DATASET.csv")

    """min support 0.001"""
    minSupport = float(100)/float(100000)
    minConfidence = 0

    items, rules = runApriori(inFile, minSupport, minConfidence)

    printResults(items, rules)
    print("--- %s seconds ---" % (time.time() - start_time))
